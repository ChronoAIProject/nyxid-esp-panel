
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#define portMAX_DELAY 0
#define pdMS_TO_TICKS(x) (x)
static pthread_mutex_t capture_mutex=PTHREAD_MUTEX_INITIALIZER;
#define wake_lock (&capture_mutex)
static pthread_mutex_t event_mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t event_cond=PTHREAD_COND_INITIALIZER;
static atomic_bool wake_listening;
static atomic_int_fast64_t wake_yield_until;
static void *wake_call;
static bool waiting,allow_wait,release_called,early_release;
int xSemaphoreTake(pthread_mutex_t *m,int timeout) {(void)timeout;return pthread_mutex_lock(m);}
int xSemaphoreGive(pthread_mutex_t *m) {return pthread_mutex_unlock(m);}
int64_t esp_timer_get_time(void) {return 123456;}
void vTaskDelay(int ticks) {
    if(ticks!=10)return;
    pthread_mutex_lock(&event_mutex);
    waiting=true;pthread_cond_broadcast(&event_cond);
    while(!allow_wait)pthread_cond_wait(&event_cond,&event_mutex);
    pthread_mutex_unlock(&event_mutex);
}
void product_audio_release(void) {
    pthread_mutex_lock(wake_lock);
    bool attached=wake_call!=NULL;
    pthread_mutex_unlock(wake_lock);
    pthread_mutex_lock(&event_mutex);
    early_release=attached;release_called=true;
    pthread_cond_broadcast(&event_cond);
    pthread_mutex_unlock(&event_mutex);
}
static void *run_tail(void *arg) {
    (void)arg;
        atomic_store(&wake_listening,false);
        // Read/processing/FIFO errors can leave the loop before call_task has
        // joined its audio workers. Keep exclusive ownership until that task
        // detaches the call; let it acquire wake_lock while we wait.
        for (;;) {
            xSemaphoreTake(wake_lock,portMAX_DELAY);
            bool attached=wake_call!=NULL;
            xSemaphoreGive(wake_lock);
            if(!attached)break;
            vTaskDelay(pdMS_TO_TICKS(10));
        }
        product_audio_release();
        atomic_store(&wake_yield_until,esp_timer_get_time()+2000000);
        vTaskDelay(pdMS_TO_TICKS(100));
    return NULL;
}
int main(int argc,char **argv) {
    alarm(5);
    bool pending=argc==2 && strcmp(argv[1],"pending")==0;
    int call=1;
    wake_call=pending?&call:NULL;
    atomic_store(&wake_listening,true);
    pthread_t thread;
    if(pthread_create(&thread,NULL,run_tail,NULL))return 10;
    pthread_mutex_lock(&event_mutex);
    while(!waiting && !release_called)pthread_cond_wait(&event_cond,&event_mutex);
    bool held=pending && waiting && !release_called;
    if(held) {
        // Represents call_task detaching only after peer/mic/speaker/tone join.
        // Taking the real capture mutex here also detects waiting under it.
        pthread_mutex_lock(wake_lock);wake_call=NULL;pthread_mutex_unlock(wake_lock);
    }
    allow_wait=true;pthread_cond_broadcast(&event_cond);
    pthread_mutex_unlock(&event_mutex);
    pthread_join(thread,NULL);
    bool ok=release_called && !early_release && (!pending || held)
        && !atomic_load(&wake_listening) && atomic_load(&wake_yield_until)==2123456;
    printf("{\"pending_call\":%s,\"held_until_detach\":%s,\"premature_release\":%s,\"contract_passed\":%s}\n",
        pending?"true":"false",held?"true":"false",early_release?"true":"false",ok?"true":"false");
    return ok?0:1;
}
