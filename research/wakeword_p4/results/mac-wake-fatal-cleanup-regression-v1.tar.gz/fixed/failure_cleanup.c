
#include <assert.h>
#include <setjmp.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void *allocations[32];
static int released, stopped;
static jmp_buf exited;
static atomic_bool wake_listening;
static char last_status[32];
static void *model,*models,*root,*aec,*agc,*capture,*mic,*ref,*clean,*adjusted,*detect;
static int wn_chunk=480;
static void *allocate(void) {
    for(int i=0;i<32;i++)if(!allocations[i]) {
        allocations[i]=malloc(16);assert(allocations[i]);return allocations[i];
    }
    abort();
}
static bool live(void *p) {
    if(!p)return false;
    for(int i=0;i<32;i++)if(allocations[i]==p)return true;
    return false;
}
static void tracked_free(void *p) {
    if(!p)return;
    for(int i=0;i<32;i++)if(allocations[i]==p) {
        free(p);allocations[i]=NULL;return;
    }
    assert(!"double free or foreign pointer");
}
#define free tracked_free
static void destroy_model(void *p) {assert(live(models)&&live(root));free(p);}
static int sample_rate(void *p) {(void)p;return 16000;}
static int channels(void *p) {(void)p;return 1;}
static const struct iface {
    void (*destroy)(void *);
    int (*get_samp_rate)(void *);
    int (*get_channel_num)(void *);
} iface={destroy_model,sample_rate,channels}, *wn=&iface;
static void aec_destroy(void *p) {free(p);}
static void esp_agc_close(void *p) {free(p);}
static void srmodel_host_deinit(void *p) {assert(!live(model)&&live(root));free(p);}
static bool prime_wake_model(const struct iface *w,void *m,void *d,int c) {
    (void)w;(void)m;(void)d;(void)c;return false;
}
static void wake_status(const char *s) {snprintf(last_status,sizeof(last_status),"%s",s);}
static void product_audio_release(void) {released++;}
static _Noreturn void vTaskDelete(void *p) {(void)p;stopped++;longjmp(exited,1);}
#define ESP_LOGE(...) ((void)0)

static void exercise(int scenario) {
if(scenario==0){
if(!model || !aec || !agc || !capture || !mic || !ref || !clean || !adjusted || !detect ||
                wn->get_samp_rate(model)!=16000 || wn->get_channel_num(model)!=1 ||
                !prime_wake_model(wn,model,detect,wn_chunk)) {
                goto unavailable;
            }
}
if(scenario==1 || scenario==2){
if(!model || !prime_wake_model(wn,model,detect,wn_chunk)) {
                goto unavailable;
            }
}
if(scenario==3){
if(!aec){goto unavailable;}
}

abort();

unavailable:
    // The model borrows names/weights from models/root across rearm cycles.
    // Keep those owners reachable until every fatal exit has destroyed it.
    atomic_store(&wake_listening,false);
    if(model)wn->destroy(model);
    if(aec)aec_destroy(aec);
    if(agc)esp_agc_close(agc);
    if(models)srmodel_host_deinit(models);
    free(root);
    free(capture);free(mic);free(ref);free(clean);free(adjusted);free(detect);
    wake_status("unavailable");product_audio_release();
    ESP_LOGE("panel.wake","%s listener initialization or rearm failed",panel_voice_wake_word());
    vTaskDelete(NULL);
}

int main(int argc,char **argv) {
    assert(argc==2);int scenario=atoi(argv[1]);
    root=allocate();models=allocate();model=allocate();aec=allocate();agc=allocate();
    capture=allocate();mic=allocate();ref=allocate();clean=allocate();adjusted=allocate();detect=allocate();
    if(scenario==0){free(detect);detect=NULL;}
    if(scenario==1){destroy_model(model);model=NULL;}
    if(scenario==3){aec_destroy(aec);aec=NULL;}
    atomic_store(&wake_listening,false);
    if(!setjmp(exited))exercise(scenario);
    int retained=0;for(int i=0;i<32;i++)retained+=allocations[i]!=NULL;
    bool ok=!retained&&released==1&&stopped==1&&!strcmp(last_status,"unavailable");
    printf("{\"scenario\":%d,\"retained_allocations\":%d,\"audio_releases\":%d,\"task_exits\":%d,\"passed\":%s}\n",
           scenario,retained,released,stopped,ok?"true":"false");
    /* Release instrumentation leftovers after measuring the actual exit. */
    for(int i=0;i<32;i++)if(allocations[i])tracked_free(allocations[i]);
    return ok?0:1;
}
