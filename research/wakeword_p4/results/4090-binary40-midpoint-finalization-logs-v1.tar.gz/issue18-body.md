固定alpha=.5权重中点（零次优化器更新）的最终INT8导出和全部8组既有评测已结束；独立归档/成员校验、来源身份及完整执行回执通过。结果已推送 1fdf711d6c9322473ba849d3e59952ddda6ce917。

# Fixed midpoint complete comparison

Consumed synthetic evidence only; no automatic promotion, pooled reused background hours, independent acceptance, human-generalization, phonetic endpoint, first-command retention or P4 claim. Other/nearword groups remain in complete original reports and are not a zero-error gate. Fixed derived alpha=.5 checkpoint; no new optimizer updates or causal regularization claim.

| Metric | C161 | Original Binary40 | Prior teacher | Midpoint |
|---|---:|---:|---:|---:|
| builtin | 5/12 | 8/12 | 10/12 | 9/12 |
| continuous_gap32000 | 2/12 | 8/12 | 10/12 | 8/12 |
| continuous_gap8000 | 0/12 | 7/12 | 11/12 | 11/12 |
| daily_conflict_clips | 0/96 | 1/96 | 1/96 | 1/96 |
| jenny/all | 33/36 | 33/36 | 30/36 | 31/36 |
| jenny/bare | 9/9 | 9/9 | 9/9 | 9/9 |
| jenny/commands | 24/27 | 24/27 | 21/27 | 22/27 |
| joe/all | 0/72 | 17/72 | 17/72 | 16/72 |
| joe/unclassified | 0/72 | 17/72 | 17/72 | 16/72 |
| mac_host | 1/4 | 2/4 | 2/4 | 2/4 |
| melo/EN-BR/all | 21/36 | 20/36 | 13/36 | 15/36 |
| melo/EN-BR/bare | 7/9 | 6/9 | 3/9 | 3/9 |
| melo/EN-BR/commands | 14/27 | 14/27 | 10/27 | 12/27 |
| melo/EN-US/all | 33/36 | 33/36 | 32/36 | 30/36 |
| melo/EN-US/bare | 9/9 | 8/9 | 8/9 | 7/9 |
| melo/EN-US/commands | 24/27 | 25/27 | 24/27 | 23/27 |
| primed/all | 35/36 | 36/36 | 34/36 | 35/36 |
| primed/bare | 9/9 | 9/9 | 9/9 | 9/9 |
| primed/commands | 26/27 | 27/27 | 25/27 | 26/27 |

Exact clip gains/losses, daily utterances, each reused background set and source hashes are preserved in 4090-binary40-midpoint-final-summary-v1.json. No automatic model selection.


仅测试预先固定的一组父模型和alpha=.5，不扫系数或阈值。尚无自动晋升或实机合格结论：C161仍为基准，后续需审查逐条普通命中损失、常用词冲突，并结合Mac独立P4数值、首句命令、资源、实时性和稳定性。完整原始报告、逐条得失和独立复核均已保留。
